/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.isi.test12;

public class Macaz {

  private String idMacaz;
  private Linie linieSursa;
  private Linie[] linieDestinatie;

  public Macaz(String idMacaz) {

    this.idMacaz = idMacaz;
  }

  public Macaz(Linie linieSursa) {

    this.linieSursa = linieSursa;
  }

  public Macaz() {

  }

  public Macaz(Linie[] linieDestinatie) {

    this.linieDestinatie = linieDestinatie;
  }

  public Macaz(Object idMacaz) {

    this.idMacaz = idMacaz.toString();
  }

  public boolean isInList(String idName) {
    if (this.idMacaz.equals(idName)) {
      return true;
    }

    if (this.linieDestinatie.equals(idName)) {
      return true;
    }
    if (this.linieSursa.equals(idName)) {
      return true;
    } else {

      return false;
    }
  }

  public String getIdMacaz() {
    return idMacaz;

  }

  public Linie getLinieSursa() {
    return linieSursa;
  }

  public Linie[] getLinieDestinatie() {
    return linieDestinatie;
  }

  /* public Macaz(Object mid, Object source, Object[] dest) {
    this.idMacaz = mid.toString();
    this.linieSursa = (Linie) source;
    this.linieDestinatie = (Linie[]) dest;
  }*/

  public void toString(String idMacaz, Linie linieSursa, Linie[] linieDestinatie) {
    System.out.println("Macazul " + this.idMacaz + ": " + "linie sursa: " + this.getLinieSursa() + ", " + "linii destinatii: " + this.getLinieDestinatie());
  }

  public Macaz(Object mid, Object source, Object[] dest) {
    super();
    this.idMacaz = mid.toString();
    this.linieSursa = (Linie) source;
    this.linieDestinatie = (Linie[]) dest;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((idMacaz == null) ? 0 : idMacaz.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Macaz other = (Macaz) obj;
    if (idMacaz == null) {
      if (other.idMacaz != null)
        return false;
    } else if (!idMacaz.equals(other.idMacaz))
      return false;
    return true;
  }

  /* public void addConection(Object mid, Object source, Object[] dest) {
    System.out.println("Macazul " + this.idMacaz + ": " + "linie sursa: " + this.linieSursa + ", " + "linii destinatii: " + this.linieDestinatie);
  
  }
  */
  /* public void addConection(Object mid, Object source, Object[] dest) {
    System.out.println("Macazul " + this.getIdMacaz().toString() + ": " + "linie sursa: " + this.linieSursa + ", " + "linii destinatii: " + this.linieDestinatie);
  }
  */

}
