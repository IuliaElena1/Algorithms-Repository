/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.isi.test12;

import java.util.ArrayList;
import java.util.List;

public class DepotImpl implements Depot {
  private List<Macaz> macaze = new ArrayList<>();

  private List<Macaz> conectionsSolutions = new ArrayList<>();
  private List<Linie> linii = new ArrayList<>();

  @Override
  public Object addLine(String id) {

    Linie linie = switchLineStringInAnObject(id);

    if (linie == null) {
      linie = new Linie(id);
      linii.add(linie);
      return linie;

    }

    return null;

  }

  public Linie switchLineStringInAnObject(String idLine) {
    for (Linie linie : linii) {
      if (linie.isLineOf(idLine)) {

        return linie;
      }

    }
    return null;

  }

  @Override
  public Object addSwitch(String id) {

    Macaz macaz = switchStringInAMacazObject(id);

    if (macaz == null) {
      macaz = new Macaz(id);
      macaze.add(macaz);
      return macaze;
    }

    return null;

  }

  private Macaz switchStringInAMacazObject(String idMacaz) {

    for (Macaz macaz : macaze) {
      if (macaz.isInList(idMacaz)) {
        return macaz;
      }
    }
    return null;
  }

  @Override
  public void setConnections(Object mid, Object source, Object[] dest) {

    /* Macaz mc = new Macaz();
    String macaz = addSwitch((String) mid).toString();
    String linieSursa = addLine((String) source).toString();
    String[] destinatie = new String[dest.length];
    
    mc.addConection(macaz, linieSursa, destinatie);*/

  }

  @Override
  public void showPath(Object start, Object stop) {
    /*   Macaz macaz = new Macaz();
    LinieSursa startLine = new LinieSursa(start);
    LinieDestinatie destination = new LinieDestinatie(stop);
    
    Macaz macazPath = new Macaz();
    showPathConnection(conectionsSolutions, startLine, destination);
    // conectionsSolutions = setConnections(macaz, startLine, destination);
    */
  }

  /*  private void showPathConnection(List<Macaz> conectionsSolutions, LinieSursa startLine, LinieDestinatie destination) {
  
    if (conectionsSolutions.contains(startLine)) {
      return;
    }
  
     conectionsSolutions.addConnection(startLine);
  
  }*/

  @Override
  public void switchTrains(Object start, Object stop) {

  }

  public static void main(String[] args) {

    DepotImpl dp = new DepotImpl();

    // dp.addLine("l3");

    Object m1 = dp.addSwitch("m1");
    Object l1 = dp.addLine("L1");
    Object l5 = dp.addLine("l6");

    System.out.println(m1);
    System.out.println(l1);
    System.out.println(l5);
    dp.setConnections(m1, l1, new Object[] { l1, l5 });

  }

  public void showConnection() {
    System.out.println(macaze);
  }

}
