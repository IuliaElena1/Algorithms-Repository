/*
 * Copyright (c) 2011 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/csilistru/test14/src/com/ssn/ssijs/test14/Handlers.java,v 1.1 2019/03/28 12:27:16 csilistru Exp $
 */

package com.ssn.ssijs.test14;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Handlers {

  private List<Zona> zone = new ArrayList<>();
  private List<Locatie> locatii = new ArrayList<>();
  private List<SetCoordonate> coordonate = new ArrayList<>();
  private List<Articol> articole = new ArrayList<>();
  private List<Palet> paleti = new ArrayList<>();

  private Map<Articol, Zona> mapZone = new HashMap<>();

  List<Locatie> infosLocatie = new ArrayList<>();

  public void addNewZone(String name) {
    Zona numeZone = getZonaByName(name);
    if (numeZone == null) {
      numeZone = new Zona(name);
      zone.add(numeZone);
    } else {
      System.out.println("Numele zonei exista deja!");
    }

  }

  private Zona getZonaByName(String name) {
    for (Zona zona : zone) {
      if (zona.hasName(name)) {
        return zona;
      }

    }
    return null;
  }

  public void addNewLocation(String nume, String x, String y, String z, String zona) {

    Locatie numeLocatie = getLocatieByName(nume);
    SetCoordonate coordonateNume = getCooronateByName(x, y, z);
    Zona numeZona = getZonaByName(zona);

    if (numeZona == null) {
      numeZona = new Zona(zona);
      zone.add(numeZona);
    }

    if (coordonateNume == null) {
      coordonateNume = new SetCoordonate(x, y, z);
      coordonate.add(coordonateNume);
    }

    if (numeLocatie == null) {
      numeLocatie = new Locatie(nume);
      locatii.add(numeLocatie);
    }

    Locatie locatie = new Locatie(numeLocatie, coordonateNume, numeZona);
    infosLocatie.add(locatie);

  }

  private SetCoordonate getCooronateByName(String x, String y, String z) {
    for (SetCoordonate coordonata : coordonate) {
      if (coordonata.hasName(x, y, z)) {
        return coordonata;

      }
    }

    return null;
  }

  private Locatie getLocatieByName(String nume) {

    for (Locatie locatie : locatii) {
      if (locatie.hasNameLocatie(nume)) {
        return locatie;
      } else {
        System.out.println("Locatia introdusa exista deja in sistem");
      }

    }
    return null;
  }

  public void addNewArticle(String nume, String qty, String zona) {

    Articol articol = getArticolByName(nume);
    if (articol == null) {
      articol = new Articol(nume, qty);
      articole.add(articol);

    }

    Zona numeZona = getZonaByName(zona);

    if (numeZona == null) {
      numeZona = new Zona(zona);
      zone.add(numeZona);
    }

    mapZone.put(articol, numeZona);

    /*   articol.makeConection(zona);*/

  }

  private void makeConection(Articol articol, String zona) {
    // TODO Auto-generated method stub

  }

  private Articol getArticolByName(String nume) {
    for (Articol articol : articole) {
      if (articol.hasNameArticol(nume)) {
        return articol;
      }
    }

    return null;
  }

  /*private Articol getArticolByName(String nume, String qty, String zona) {
    for (Articol articol : articole) {
      if (articol.hasNameArticol(nume, qty, zona)) {
        return articol;
      }
    }
  
    return null;
  }*/

  public void addNewPallet(String id, String nume, String qty) {

    /* Palet paletId = new Palet(id);
    if (paletId == null) {
      paleti.add(paletId);
    }*/

    Palet paletName = getPaletByName(id, nume, qty);
    if (paletName == null) {
      paleti.add(paletName);
    }

  }

  private Palet getPaletByName(String id, String nume, String qty) {
    for (Palet palet : paleti) {
      if (palet.hasNamePalet(id, nume, qty)) {
        return palet;
      }
    }

    return null;
  }

  public void getPallet(String id) {

    for (Palet palet : paleti) {
      if (!palet.getIdPalet().contains(id)) {
        paleti.add(palet);
      } else {
        System.out.println(palet);
      }
    }

  }

  public void getArticles(String nume, String qty) {

    for (Articol articol : articole) {

    }
  }

  public void showHistory() {
    System.out.println("showHistory() called");
  }

  public void showStatistics() {
    System.out.println("showStatistics() called");
  }

  public void showStatus() {

  }

  public static void main(String[] args) {
    Handlers hd = new Handlers();
    hd.addNewArticle("mere", "100", "mere");
    hd.addNewZone("leguma");
    hd.addNewLocation("mere", "2", "3", "2", "pere");
    hd.addNewPallet("12", "mmmm", "50");
    System.out.println(hd.paleti);
    System.out.println(hd.infosLocatie);
    System.out.println(hd.articole);
    System.out.println(hd.zone);
    /*   System.out.println(hd.articole);
    System.out.println(hd.zone);
    System.out.println(hd.articole);
    System.out.println(hd.locatii);*/

  }

}
