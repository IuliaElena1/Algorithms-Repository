
package com.ssn.ssijs.test14;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class UI {
  private Handlers handlers;

  /**
   * @param handlers
   */
  public UI(Handlers handlers) {
    this.handlers = handlers;
  }

  public static void p(String s) {
    System.out.print(s);
  }

  public static void pl(String s) {
    System.out.println(s);
  }

  public String readOption() {
    try {
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      String s = br.readLine();
      return s;
    } catch (Exception e) {
      pl("Exception while reading from keyboard");
    }
    return null;
  }

  /**
   * @throws IOException 
   * 
   */
  public void runMenu() throws IOException {
    MenuItem mainMenu = new MenuItem(null, "Meniu principal", null);
    MenuItem menuConfigurare = new MenuItem("1", "Configurare", null);
    MenuItem menuManagement = new MenuItem("2", "Management", null);

    MenuItem menuCreareZona = createMenuCreateZone();
    MenuItem menuCreareLoc = createMenuCreateLocation();
    MenuItem menuCreareArticol = createMenuCreateArticle();

    MenuItem menuShowStatus = createMenuShowStatus();
    MenuItem menuAddPallet = createMenuAddPallet();
    MenuItem menuGetPallet = createMenuGetPallet();
    MenuItem menuGetArticle = createMenuGetArticle();
    MenuItem menuShowStatistics = createMenuShowStatistics();
    MenuItem menuShowHistory = createMenuShowHistory();

    mainMenu.addSubMenu(menuConfigurare).addSubMenu(menuManagement);
    menuConfigurare.addSubMenu(menuCreareZona).addSubMenu(menuCreareLoc).addSubMenu(menuCreareArticol);
    menuManagement.addSubMenu(menuShowStatus).addSubMenu(menuAddPallet).addSubMenu(menuGetPallet).addSubMenu(menuGetArticle).addSubMenu(menuShowStatistics).addSubMenu(menuShowHistory);

    run(mainMenu);
  }

  /**
   * @return
   */
  private MenuItem createMenuShowStatus() {
    MenuItem menu = new MenuItem("1", "Stare depozit", new MenuHandler() {

      @Override
      public void execute() {
        handlers.showStatus();
      }

    });

    return menu;
  }

  /**
   * @return
   */
  protected MenuItem createMenuShowHistory() {
    MenuItem menu = new MenuItem("6", "Istoric operatiuni", new MenuHandler() {

      @Override
      public void execute() {
        handlers.showHistory();
      }

    });

    return menu;
  }

  /**
   * @return
   */
  protected MenuItem createMenuShowStatistics() {
    MenuItem menu = new MenuItem("5", "Statistici", new MenuHandler() {

      @Override
      public void execute() {
        handlers.showStatistics();
      }

    });

    return menu;
  }

  /**
   * @return
   */
  protected MenuItem createMenuGetArticle() {
    MenuItem menu = new MenuItem("4", "Scoatere articole", new MenuHandler() {

      @Override
      public void execute() {
        p("Nume articol: ");
        String nume = readOption();
        p("Cantitatea ce se doreste scoasa: ");
        String qty = readOption();
        handlers.getArticles(nume, qty);
      }

    });

    return menu;
  }

  /**
   * @return
   */
  protected MenuItem createMenuGetPallet() {
    MenuItem menu = new MenuItem("3", "Scoatere palet", new MenuHandler() {

      @Override
      public void execute() {
        p("ID palet: ");
        String id = readOption();
        handlers.getPallet(id);
      }

    });
    return menu;
  }

  /**
   * @return
   */
  protected MenuItem createMenuAddPallet() {
    MenuItem menu = new MenuItem("2", "Adaugare palet nou", new MenuHandler() {

      @Override
      public void execute() {
        p("ID palet: ");
        String id = readOption();
        p("Nume articol: ");
        String nume = readOption();
        p("Cantitate: ");
        String qty = readOption();
        handlers.addNewPallet(id, nume, qty);
      }

    });
    return menu;
  }

  /**
   * @return
   */
  protected MenuItem createMenuCreateArticle() {
    MenuItem menuCreareArticol = new MenuItem("3", "Creare articol", new MenuHandler() {

      @Override
      public void execute() {
        p("Nume articol: ");
        String nume = readOption();
        p("Cantitatea maxima pe palet: ");
        String qty = readOption();
        p("Zona specifica articolului: ");
        String zona = readOption();
        handlers.addNewArticle(nume, qty, zona);
      }

    });
    return menuCreareArticol;
  }

  /**
   * @return
   */
  protected MenuItem createMenuCreateLocation() {
    MenuItem menuCreareLoc = new MenuItem("2", "Creare locatie", new MenuHandler() {

      @Override
      public void execute() {
        p("Numele locatiei: ");
        String n = readOption();
        p("X: ");
        String x = readOption();
        p("Y: ");
        String y = readOption();
        p("Z: ");
        String z = readOption();
        p("Zona locatiei: ");
        String zona = readOption();
        handlers.addNewLocation(n, x, y, z, zona);
      }

    });
    return menuCreareLoc;
  }

  /**
   * @return
   */
  protected MenuItem createMenuCreateZone() {
    MenuItem menuCreareZona = new MenuItem("1", "Creare zona", new MenuHandler() {

      @Override
      public void execute() {
        p("Numele zonei: ");
        String s = readOption();
        handlers.addNewZone(s);
      }

    });
    return menuCreareZona;
  }

  /**
   * @param menu 
   * @throws IOException 
   */
  protected void run(MenuItem menu) throws IOException {
    while (true) {
      showMenus(menu);

      String option = readOption();

      if (option.equals("0")) {
        return;
      }

      boolean invalidOption = true;
      for (MenuItem mi : menu.subMenus) {
        if (mi.choice.equals(option)) {
          if (mi.handler != null) {
            pl(mi.name);
            mi.handler.execute();
            invalidOption = false;
          } else {
            run(mi);
            invalidOption = false;
          }
        }
      }

      if (invalidOption) {
        pl("Optiune invalida");
      }
    }
  }

  /**
   * @param menu
   */
  protected void showMenus(MenuItem menu) {
    for (MenuItem mi : menu.subMenus) {
      pl(mi.choice + " - " + mi.name);
    }

    pl("0 - Back");
    pl("---------");
  }

}
