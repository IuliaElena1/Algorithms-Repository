/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/csilistru/isi_test12/src/com/ssn/ssijs/isi/test12/Path.java,v 1.1 2019/03/22 11:28:29 csilistru Exp $
 */

package com.ssn.ssijs.isi.test12;

public class Path {

}
