/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.isi.test12;

import java.util.ArrayList;

public class TestApplication {

  public static void main(String[] args) {
    String str = "one" + System.lineSeparator() + "two";
    System.out.println(str);

    System.out.println();

    Object[] arr = { "l1", "l2" };
    /*
    String str1 = Arrays.toString(arr);
    
    StringBuilder builder = new StringBuilder();
    for (Object s : arr) {
      builder.append(s);
    }
    String str11 = builder.toString();*/

    /*    StringBuffer result = new StringBuffer();
    for (int i = 0; i < arr.length; i++) {
      result.append(", " + arr[i]);
      //result.append( optional separator );
    }
    String mynewstring = result.toString();
    System.out.println(mynewstring.replaceFirst(",", ""));
      }*/

    ArrayList<String> list = new ArrayList<String>();
    list.add("one");
    list.add("two");
    list.add("three");

    String listString = "";

    for (String s : list) {
      listString += s + " ";
    }

    System.out.println(listString);

  }
}

/*  {
  dp = new DepotImpl();
  dp.addLine("L1");
  dp.addLine("L2");
  dp.addLine("L3");
  dp.addLine("L4");

}*/
