/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.isi.test12;

public class PozitieMacaz {

  private int pozitia;

  public PozitieMacaz(int pozitia) {
    super();
    this.pozitia = pozitia;
  }

  public int getPozitia1() {
    return pozitia;
  }

  /*  public return int  casePozition(int pozitia){
  switch(pozitia){
    case 1 : "Switch "
  }
  */
}
