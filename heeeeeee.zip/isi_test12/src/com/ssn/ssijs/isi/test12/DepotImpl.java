
package com.ssn.ssijs.isi.test12;

import java.util.ArrayList;
import java.util.List;

public class DepotImpl implements Depot {
  private List<Macaz> macaze = new ArrayList<Macaz>();

  private List<Linie> linii = new ArrayList<>();
  private List<Linie> solutions = new ArrayList<>();
  //  private Path paths = new Path();

  @Override
  public Object addLine(String id) {

    Linie linie = switchLineStringInAnObject(id);

    if (linie == null) {
      linie = new Linie(id);
      linii.add(linie);
      return linie;

    }

    return null;

  }

  public Linie switchLineStringInAnObject(String idLine) {
    for (Linie linie : linii) {
      if (linie.isLineOf(idLine)) {

        return linie;
      }

    }
    return null;

  }

  @Override
  public Object addSwitch(String id) {

    Macaz macaz = switchStringInAMacazObject(id);

    if (macaz == null) {
      macaz = new Macaz(id);

      return macaz;

    }

    return null;

  }

  private Macaz switchStringInAMacazObject(String idMacaz) {

    for (Macaz macaz : macaze) {
      if (macaz.isInList(idMacaz)) {
        return macaz;
      }
    }
    return null;
  }

  @Override
  public void setConnections(Object mid, Object source, Object[] dest) {

    Macaz macaz = new Macaz(mid);

    Linie linieSursa = new Linie(source);

    String destToString = displayAnArrayObjectInAToStriing(dest);

    System.out.println("Macazul " + macaz + ": " + "linie sursa: " + linieSursa.toString() + ", " + "linii destinatii:" + destToString);
  }

  private String displayAnArrayObjectInAToStriing(Object[] dest) {
    Linie[] destinatie = convertAnArrayOfObjectsInAnotherTypeObject(dest);

    StringBuffer result = new StringBuffer();
    for (int i = 0; i < destinatie.length; i++) {
      result.append(", " + destinatie[i]);

    }
    String newString = result.toString();
    return newString.replaceFirst(",", "");
  }

  private Linie[] convertAnArrayOfObjectsInAnotherTypeObject(Object[] dest) {
    Linie[] destinatie = new Linie[dest.length];
    int indexDestinatie = 0;
    for (int i = 0; i < dest.length; i++) {
      destinatie[indexDestinatie] = (Linie) dest[i];
      indexDestinatie++;
    }

    return destinatie;
  }

  @Override
  public void showPath(Object start, Object stop) {
    //Object start : contine toat proprietatile obiectului Linie
    Linie startLinie = (Linie) start;
    Linie stopLinie = (Linie) stop;
    Macaz curentSolution = new Macaz();
    solutions.clear();

    searchRoute(startLinie, stopLinie, curentSolution);

  }

  private void searchRoute(Linie current, Linie stopTren, Macaz solution) {

    /*    //evitam buclele
    if (solution.contains(current)) {
      return;
    }
    
    //adaugam linia curenta la drumul curent
    solution.adaugareLinieCurenta(current);
    
    if (solution.equals(stopTren)) {
      solutions.add(solution.clone());
    } else {
      Macaz macazDirection = solution.
    
    }*/

  }

  @Override
  public void switchTrains(Object start, Object stop) {

  }

  public static void main(String[] args) {

    DepotImpl dp = new DepotImpl();

    // dp.addLine("l3");

    Object m1 = dp.addSwitch("m1");
    Object m2 = dp.addSwitch("m2");
    Object m3 = dp.addSwitch("m3");
    Object m4 = dp.addSwitch("m4");
    Object l1 = dp.addLine("L1");
    Object l2 = dp.addLine("L2");
    Object l3 = dp.addLine("L3");
    Object l4 = dp.addLine("L4");
    Object l5 = dp.addLine("L5");
    Object l6 = dp.addLine("L6");
    Object l7 = dp.addLine("L7");
    Object l8 = dp.addLine("L8");

    // Object[] l3 = new Object[l2,l5];

    System.out.println(m1);
    System.out.println(l1);
    System.out.println(l5);
    dp.setConnections(m1, l1, new Object[] { l2, l4 });
    dp.setConnections(m2, l3, new Object[] { l2, l5 });
    dp.setConnections(m3, l6, new Object[] { l7, l5 });
    dp.setConnections(m4, l8, new Object[] { l4, l7 });

    //System.out.println(dp.displayOnObjectInAToStriing(new Object[] { l2, l5 }));

  }

}